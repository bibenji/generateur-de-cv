﻿<?php
session_start();
?>
<html>
<head>
<title></title>
</head>
<body>

<div id="ide">
<?php var_dump($_SESSION['data']); ?>
</div>

<p>Paris, le 29/08/2016</p>

<p>Objet :</p>

<p>Madame, Monsieur,</p>

<p>Actuellement à la recherche d'un emploi, je me permets de vous faire par de cette candidature pour un poste de ___ au sein de votre structure.</p>

<p>Vous trouverez ci-joint mon CV qui retrace mon parcours.</p>

<p>Je suis une personne [qual1] et [qual2]. Des qualités que je saurais mettre en avant au sein de votre équipe.</p>

<p>En espérant vivement que ma candidature retienne votre attention, je me tiens à votre disposition pour toute information complémentaire.</p>

<p>Je souhaiterais, par ailleurs, si ma candidature vous intéresse, pouvoir vous rencontrer et vous exposer de vive voix mes motivations au cours d'un entretien à votre convenance.</p>

<p>Je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées.</p>

<p>DOE John</p>

</body>
</html>