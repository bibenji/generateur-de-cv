﻿<html>
<head>
<title></title>
</head>
<style>
div {
	border: solid blue 1px;
	background-color: green;
	
}

#one { width: 600px; height: 200px;}
#two { width: 300px; height: 150px; display: inline;}
#three { width: 200px; height: 150px; display: inline;}
</style>

<body>

<h1>Yo</h1>

<div id="one">
	<div id="two">two</div>
	<div id="three">three</div>
</div>

</body>
</html>