﻿<header>
	<div class="bandeau_haut">
			<span class="login">Login</span><span class="login">Sign In</span>
		</div>
	
	<div class="zone_titre">
			<h1>Curriculum</h1>
			<span id="soustitre">Vite Fait</span>
	</div>
</header>