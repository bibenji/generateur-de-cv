﻿<h1>Test</h1>

<pre>
<?php print_r($_POST); ?>
</pre>
