﻿<?php
session_start();
session_destroy();
?>
<a href="index.php">Back</a>